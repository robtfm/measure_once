Measure once, Copyright 2022 robtfm (robtfm@gmail.com)

Sound fx: Zapsplat (https://www.zapsplat.com)
Music: "Banjos, Unite!" by Alexander Nakarada (www.serpentsoundstudios.com). Licensed under Creative Commons BY Attribution 4.0 License (https://creativecommons.org/licenses/by/4.0/)
Font: https://fontsforyou.com/